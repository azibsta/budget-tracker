<?php

class AdvisorController {
    private $advisorModel;

    public function __construct($advisorModel) {
        $this->advisorModel = $advisorModel;
    }

    public function analyzeFinancialData($userId) {
        $financialData = $this->advisorModel->getUserFinancialData($userId);
        // Perform analysis on financial data
        // This is a placeholder for analysis logic
        $advice = $this->generateFinancialAdvice($financialData);
        include '../views/analyze.php';
    }

    public function provideFinancialAdvice($userId) {
        $financialData = $this->advisorModel->getUserFinancialData($userId);
        // Generate advice based on financial data
        // This is a placeholder for advice generation logic
        $advice = $this->generateFinancialAdvice($financialData);
        return $advice; // Return financial advice
    }

    public function setFinancialGoals($userId, $goals) {
        // Save financial goals to the database
        $this->advisorModel->saveFinancialGoals($userId, $goals);
        include '../views/goalsView.php';
    }

    private function generateFinancialAdvice($financialData) {
        // Placeholder for generating financial advice based on data
        $allAdvice = [
            "Consider saving more for retirement.",
            "Reduce unnecessary expenses.",
            "Invest in a diversified portfolio.",
            "Create an emergency fund.",
            "Track your spending to identify areas where you can cut costs.",
            "Pay off high-interest debt as soon as possible.",
            "Set up automatic transfers to your savings account.",
            "Review your insurance policies to ensure adequate coverage.",
            "Plan for major expenses in advance to avoid financial stress.",
            "Take advantage of employer-sponsored retirement plans.",
            "Build a budget and stick to it.",
            "Increase your income by acquiring new skills.",
            "Regularly review and adjust your financial goals."
        ];

        // Shuffle the advice and return a random subset
        shuffle($allAdvice);
        return array_slice($allAdvice, 0, 5); // Return 5 random pieces of advice
    }
}

require_once '../src/models/AdvisorModel.php';
require_once '../src/controllers/AdvisorController.php';

$advisorModel = new AdvisorModel();
$advisorController = new AdvisorController($advisorModel);

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'analyze':
        $userId = $_GET['user_id'];
        $advisorController->analyzeFinancialData($userId);
        break;
    case 'set_goals':
        $userId = $_GET['user_id'];
        $goals = $_POST['goals'];
        $advisorController->setFinancialGoals($userId, $goals);
        break;
    default:
        echo "Invalid action.";
        break;
}
?>