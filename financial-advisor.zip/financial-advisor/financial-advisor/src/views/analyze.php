<!DOCTYPE html>
<html>
<head>
    <title>Financial Advice</title>
</head>
<body>
    <h1>Financial Advice</h1>
    <ul>
        <?php 
        if (!isset($advice) || !is_array($advice)) {
            $advice = ['Save more', 'Invest wisely', 'Reduce debt'];
        }
        foreach ($advice as $tip): ?>
            <li><?php echo htmlspecialchars($tip, ENT_QUOTES, 'UTF-8'); ?></li>
        <?php endforeach; ?>
    </ul>
</body>
</html>