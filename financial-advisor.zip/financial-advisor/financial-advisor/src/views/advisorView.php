<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Financial Advisor</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Financial Advisor</h1>
        
        <section id="financial-analysis">
            <h2>Analyze Your Financial Data</h2>
            <form method="POST" action="analyze.php">
                <label for="income">Monthly Income:</label>
                <input type="number" id="income" name="income" required>
                
                <label for="expenses">Monthly Expenses:</label>
                <input type="number" id="expenses" name="expenses" required>
                
                <button type="submit">Analyze</button>
            </form>
        </section>

        

        <section id="financial-goals">
            <h2>Set Your Financial Goals</h2>
            <form method="POST" action="setGoals.php">
                <label for="goal">Financial Goal:</label>
                <input type="text" id="goal" name="goal" required>
                
                <label for="amount">Target Amount:</label>
                <input type="number" id="amount" name="amount" required>
                
                <label for="deadline">Deadline:</label>
                <input type="date" id="deadline" name="deadline" required>
                
                <button type="submit">Set Goal</button>
            </form>
        </section>

        
    </div>
</body>
</html>