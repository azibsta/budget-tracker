<!DOCTYPE html>
<html>
<head>
    <title>Financial Goals</title>
</head>
<body>
    <h1>Financial Goals</h1>
    <p>Financial goals have been set successfully.</p>
</body>
</html>