<?php
require_once '../src/models/AdvisorModel.php';
require_once '../src/controllers/AdvisorController.php';

$advisorModel = new AdvisorModel();
$advisorController = new AdvisorController($advisorModel);

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'analyze':
        $userId = $_GET['user_id'];
        $advisorController->analyzeFinancialData($userId);
        break;
    case 'set_goals':
        $userId = $_GET['user_id'];
        $goals = $_POST['goals'];
        $advisorController->setFinancialGoals($userId, $goals);
        break;
    default:
        echo "Invalid action.";
        break;
}
?>