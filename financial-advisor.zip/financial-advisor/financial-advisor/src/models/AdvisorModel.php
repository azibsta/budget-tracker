<?php
class AdvisorModel {
    private $conn;

    public function __construct($dbConnection) {
        $this->conn = $dbConnection;
    }

    public function getUserFinancialData($userId) {
        $stmt = $this->conn->prepare("SELECT * FROM financial_data WHERE user_id = :user_id");
        $stmt->bindParam(':user_id', $userId);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function saveFinancialGoals($userId, $goals) {
        $stmt = $this->conn->prepare("INSERT INTO financial_goals (user_id, goal) VALUES (:user_id, :goal)");
        foreach ($goals as $goal) {
            $stmt->bindParam(':user_id', $userId);
            $stmt->bindParam(':goal', $goal);
            $stmt->execute();
        }
    }

    public function getFinancialAdvice($userId) {
        // This is a placeholder for actual advice logic
        $stmt = $this->conn->prepare("SELECT advice FROM financial_advice WHERE user_id = :user_id");
        $stmt->bindParam(':user_id', $userId);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>