<?php
require_once '../config/db.php';
require_once '../financial-advisor/src/advisor.php';

// Simple routing logic
$requestUri = $_SERVER['REQUEST_URI'];

switch ($requestUri) {
    case '/':
        // Load the main page or dashboard
        echo "Welcome to the Budget Tracker!";
        break;
    case '/financial-advisor':
        // Initialize the financial advisor feature
        $advisor = new Advisor();
        $advisor->handleRequest();
        break;
    default:
        // Handle 404 Not Found
        http_response_code(404);
        echo "404 Not Found";
        break;
}
?>